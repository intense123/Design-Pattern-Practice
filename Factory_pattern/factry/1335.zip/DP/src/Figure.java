// Abstract Figure class
abstract class Figure {
    public abstract Manipulator createManipulator();
}











