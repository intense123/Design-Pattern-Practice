public class victoriancoffeetable implements coffeetable {
    @Override
    public void  placecoffee(){
        System.out.println("This is a Victorian-style coffee table.");
    }
    
}
