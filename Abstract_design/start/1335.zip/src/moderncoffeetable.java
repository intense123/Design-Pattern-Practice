class moderncoffeetable implements coffeetable {
    @Override
    public void placecoffee() {
        System.out.println("Placing coffee on a modern coffee table");
    }
}