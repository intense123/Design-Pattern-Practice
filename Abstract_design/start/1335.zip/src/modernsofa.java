public class modernsofa implements sofa {
    @Override
    public void liedown() {
        System.out.println("ami modern sofa!");
    }

}