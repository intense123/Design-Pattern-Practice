/**
 * furniturefactory
 */
interface furniturefactory {
    chair createchair();

    sofa createsofa();

    coffeetable createcoffeetable();
}