public class artdecosofa implements sofa{
    @Override
    public void liedown(){
        System.out.println("Ghuma beda artdeco sofa eta!");
    } 
    
}
