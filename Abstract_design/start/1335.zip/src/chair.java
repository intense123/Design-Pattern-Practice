/**
 * chair
 */
interface chair {
    void sit();

    
}