public class victoriansofa implements sofa{
    @Override
    public  void liedown(){
        System.out.println( "Victorian sitting in a comfortable sofa" );
    }
    
}
