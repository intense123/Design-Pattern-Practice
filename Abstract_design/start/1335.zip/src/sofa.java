/**
 * sofa
 */
interface sofa {
    void liedown();

    
}