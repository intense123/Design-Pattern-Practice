public class victorianchair implements chair {
    @Override   
    public void sit(){
        System.out.println("this is vicorian chair!");
    }
    
}
