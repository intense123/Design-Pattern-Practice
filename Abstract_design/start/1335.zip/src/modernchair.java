public class modernchair implements chair{
    @Override
    public void sit(){
        System.out.println("Sit here, a modern chair!");
    }
    
}
