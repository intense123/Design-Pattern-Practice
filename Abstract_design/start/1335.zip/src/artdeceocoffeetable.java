public class artdeceocoffeetable implements coffeetable {
    @Override

    public void placecoffee(){
        System.out.println("this is artdeco coffee table!");
    }
    
}
