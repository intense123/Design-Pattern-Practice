interface coffeetable{
    void placecoffee();
}