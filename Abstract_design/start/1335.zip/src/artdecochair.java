public class artdecochair implements chair{
    @Override
    public void sit(){
        System.out.println("This is artdeco chair!");

    }
    
}
